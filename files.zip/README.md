# Ride-Hailing Dispatch System — CSA04 Simulator (Team 2)

Single-file C implementation of all three OS resource-management strategies
analysed in the report, verifying the hand-calculated results in Section 2
of `Ride_Hailing_Dispatch_System_CSA04_Report.docx`.

## File

`os_simulators.c` — one program, three parts, run in sequence:

| Part | Algorithms | Report section |
|------|-----------|----------------|
| I — CPU Scheduling | FCFS, SJF, Priority, Round Robin (q=3) | 2.1 / 5.1 |
| II — Page Replacement | FIFO, LRU, Optimal (4 frames, 12-ref string) | 2.2 / 5.2 |
| III — Disk Scheduling | FCFS, SSTF, SCAN, C-SCAN (head=75, cyl 0–150) | 2.3 / 5.3 |

Functions and globals from each original part are prefixed (`cpu_`, `page_`,
`disk_`) to avoid name collisions in the single translation unit; each
part's original `main()` became a `run_*()` function, called in order from
one top-level `main()`.

## Build & run

```bash
make        # gcc -Wall -O2 -o os_simulators os_simulators.c
make run    # builds, then runs it
make clean  # removes the compiled binary
```

Or directly:

```bash
gcc -Wall -O2 -o os_simulators os_simulators.c
./os_simulators
```

Full console output for the current run is saved in `all_console_output.txt`.

## Verified results (match Section 2 exactly)

**CPU Scheduling** — Avg WT / Avg TAT
- FCFS: 6.20 / 10.60
- SJF: 4.80 / 9.20
- Priority: 5.60 / 10.00
- Round Robin (q=3): 7.60 / 12.00

**Page Replacement** (4 frames, ref string `0 1 2 3 1 4 1 5 2 6 5 1`)
- FIFO: 8 faults
- LRU: 8 faults
- Optimal: 7 faults

**Disk Scheduling** (head=75, cylinders 0–150)
- FCFS: 595
- SSTF: 195
- SCAN: 215
- C-SCAN: 285

## Notes

- Report Section 4 describes the simulators as written in Python; this is
  a C implementation of the same algorithms. If the report text/excerpts
  in Section 4.1–4.3 need to match this code literally, those paragraphs
  should be edited, or this ported to Python — happy to do either.
- Fixed a display-only bug in the Round Robin Gantt chart: back-to-back
  quantum slices for the same process (e.g. P4 running twice in a row
  because it's the only process left in the ready queue) now merge into
  a single Gantt block — `P4(18-22)` instead of `P4(18-21)` + `P4(21-22)`
  — matching the report's hand-drawn chart. Waiting/turnaround-time
  figures were already correct either way.
